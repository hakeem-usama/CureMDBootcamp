﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Task2_v4
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank HBL = new Bank();
            SavingsAccount savingAccount = new SavingsAccount("ABC123","Usama",0);
            CheckingAccount checkingAccount = new CheckingAccount("DEF456", "Mohsin", 0);
            LoanAccount loanAccount = new LoanAccount("GHI789", "Haris", 100000);

            HBL.addAccount(savingAccount);
            HBL.addAccount(checkingAccount);
            HBL.addAccount(loanAccount);
            Console.WriteLine("\n\n");

            //This is example of overloading. Deposit and Widthdraw have same name but different parameters
            savingAccount.Deposit((decimal)4000.83);
            savingAccount.Withdraw((decimal)2000);
            savingAccount.Deposit((decimal)600);
            savingAccount.Withdraw((decimal)300);
            Console.WriteLine("\n\n");

            checkingAccount.Deposit();
            checkingAccount.Withdraw();
            Console.WriteLine("\n\n");

            HBL.depositToAccount(loanAccount, 6000);
            HBL.widthdrawFromAccount(loanAccount, 5000);
            //BankAccount is abstract class. We cannot create instance of this class. Following commented line will give error.
            //BankAccount newObj = new BankAccount("dsd", "gfd", 0);

            HBL.displayTransactionHistory(savingAccount);
            HBL.displayTransactionHistory(checkingAccount);
            HBL.displayTransactionHistory(loanAccount);

            Console.ReadKey();
        }
    }
}
