﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Task2_v4
{
    public abstract class BankAccount
    {
        private string account_number;
        private string account_holder_name;
        private decimal balan;
        public List<Transactions> transactions;
        public string accountNumber   // property
        {
            get { return account_number; }   // get method
            set { account_number = value; }  // set method
        }
       
        public string accountHolderName   // property
        {
            get { return account_holder_name; }   // get method
            set { account_holder_name = value; }  // set method
        }
        
        public decimal balance   // property
        {
            get { return balan; }   // get method
            set { balan = value; }  // set method
        }               
        public BankAccount(string AccountNumber, string AccountHolderName, decimal Balance)
            {
            accountNumber = AccountNumber;
            accountHolderName = AccountHolderName;
            balance = Balance;
            transactions = new List<Transactions>();            
            }
        public virtual void Deposit(decimal amountToDeposit)
        {
            balance += amountToDeposit;
            Console.WriteLine($"Amount {amountToDeposit} has been depsited in account titled as {account_holder_name}\nour new balance is {balance}");
            addTransaction(amountToDeposit,"Deposited");
        }
        public virtual void Withdraw(decimal amountToWithdraw)
        {
            if (amountToWithdraw <= balan)//private variable balan is used so that user cannot update this
            {
                balance -= amountToWithdraw;
                Console.WriteLine($"Amount {amountToWithdraw} has been widthdrawn from account titled as {account_holder_name}\nYour remaining balance is {balance}");
                addTransaction(amountToWithdraw, "Widthdraw");
            }
            else
            {
                Console.WriteLine("Low Balance. Enter the valid amount...");
            }
        }
        public virtual void addTransaction(decimal amount, string transactionType)
        {
            Transactions transactionObject = new Transactions(DateTime.Now,transactionType,amount);
            transactions.Add(transactionObject);
        }
        public abstract void CalculateInterest();// Override this method in each class to calculate the interet by different methods.
        

    }
}
