﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Task2_v4
{
    class CheckingAccount:BankAccount,ITransaction
    {
        public int SelectTransactionType;
        public decimal amountToDeposit;
        public decimal amountToWithdraw;
        public decimal AmountToDeposit;
        public decimal AmountToWithdraw;
        public decimal interest;        
        public bool transactionDeposit;
        public bool transactionWidthdraw;
        public CheckingAccount(string AccountNumber, string AccountHolderName, decimal Balance):base(AccountNumber,AccountHolderName,Balance)
        {
        }
        public void Deposit()//Overloading of function Deposit
        {
            Console.WriteLine("Enter amount to Deposit");
            AmountToDeposit =int.Parse(Console.ReadLine());
            transactionDeposit = true;
            amountToDeposit = AmountToDeposit;
            balance += amountToDeposit;
            addTransaction(amountToDeposit, "Deposited");
            PrintTransaction();

        }
        public void Withdraw()//Overloading of function Deposit
        {
            Console.WriteLine("Enter amount to Withdraw");
            AmountToWithdraw = int.Parse(Console.ReadLine());
            amountToWithdraw = AmountToWithdraw;
            transactionWidthdraw = true;
            if (amountToWithdraw <= balance)
            {
                balance -= amountToWithdraw;
                addTransaction(amountToWithdraw, "Widthdraw");
                PrintTransaction();
            }
            else
            {
                Console.WriteLine("Low Balance. Enter the valid amount...");
            }

        }
        //Since the  method CalculateInterest() is declared abstract in parent abstract class. That is why it  is must to override it in child class.
        public override void CalculateInterest()
        {
            
            Console.WriteLine("There is no intrest added in your account as your account is Checking Account");

        }
        //Since the Interface is inherited in this class. So it is necesaary to make following methods in this class. in 
        //This show the Polymorphism as you can deposit and widthdraw from individual functions as well as from ExecuteTransaction(decimal amount) method. 
        public void ExecuteTransaction(decimal amount)
        {
            Console.WriteLine("Press 1 to Deposit and 2 to withdraw from account");
            SelectTransactionType = int.Parse(Console.ReadLine());
            switch(SelectTransactionType)
            {
                case 1:
                    Deposit();
                    break;
                case 2:
                    Withdraw();
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;                       
            }
        }
        public void PrintTransaction()
        {
            if(transactionWidthdraw)
            {
                Console.WriteLine($"Amount {amountToWithdraw} has been withdrawn from account titled as {accountHolderName}\nYour remaining balance is {balance}");

            }
            else if(transactionDeposit)
            {
                Console.WriteLine($"Amount {amountToDeposit} has been deposited in account titled as {accountHolderName}\nour new balance is {balance}");
            }
            else
            {
                Console.WriteLine("Errrrrrrrrrrorrrrrrrrrrrr");
            }
            
        }

    }
}
