﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Task2_v4
{
    class Bank
    {

        public Dictionary<string, BankAccount> bankAccounts;
        public Bank()
        {
            bankAccounts = new Dictionary<string, BankAccount>();

        }
        public void addAccount(BankAccount account)
        {
            bankAccounts.Add(account.accountNumber, account);
            Console.WriteLine($"Account is added in bank detail is as:\nAcount Number:{account.accountNumber}\nAccount Title: {account.accountHolderName}\nAmount in Account: {account.balance}");
        }
        public void depositToAccount(BankAccount account, int amountToDeposit)
        {
            if (bankAccounts.ContainsKey(account.accountNumber))
            {
                bankAccounts[account.accountNumber].Deposit(amountToDeposit);
            }
            else
            {
                Console.WriteLine("This account does not exists");
            }
                
        }
        public void widthdrawFromAccount(BankAccount account, int amountToDeposit)
        {
            if (bankAccounts.ContainsKey(account.accountNumber))
            {
                bankAccounts[account.accountNumber].Withdraw(amountToDeposit);
            }
            else
            {
                Console.WriteLine("This account does not exists");
            }

        }
        public void displayTransactionHistory(BankAccount account)
        {
            if (bankAccounts.ContainsKey(account.accountNumber))
            {
                BankAccount bankAccount = bankAccounts[account.accountNumber];
                Console.WriteLine($"\nThe transaction history of account {account.accountNumber} is:\n");
                foreach(Transactions transaction in account.transactions)
                {
                    Console.WriteLine("\n");
                    Console.WriteLine($"Time of Transaction: {transaction.Date} - Transaction Type: {transaction.Type} -\n- Transaction Amount: {transaction.Amount} -- Remaining Balance: {account.balance}");
                }
            }
            else
            {
                Console.WriteLine("This account does not exists");
            }
        }
        //public List<BankAccount> BankAccounts { set; get; }
        //public Bank()
        //{
        //    BankAccounts = new List<BankAccount>();
        //    Console.WriteLine("New Bank is created");
        //}
        //public void addAccount(BankAccount account)
        //{
        //    BankAccounts.Add(account);
        //    Console.WriteLine($"Account is added in bank detail is as:\nAcount Number:{account.accountNumber}\nAccount Title: {account.accountHolderName}\nAmount in Account: {account.balance}");

        //}
        //public void DepositToAccount(BankAccount account, int amountToDeposit)
        //{
        //    account.balance += amountToDeposit;
        //    Console.WriteLine($"Amount {amountToDeposit} is deposited in account title {account.accountHolderName}\nNew balance is {account.balance}");
        //}
        //public void WithdrawFromAccount(BankAccount account, int amountToWithDraw)
        //{
        //    if (amountToWithDraw <= account.balance)
        //    {
        //        account.balance -= amountToWithDraw;
        //        Console.WriteLine($"Amount {amountToWithDraw} is widthdrawn from account title {account.accountHolderName}\nRemaining balance is {account.balance}");
        //    }
        //    else
        //    {
        //        Console.WriteLine($"Insufficent Balance");
        //    }
        //}
    }
}
