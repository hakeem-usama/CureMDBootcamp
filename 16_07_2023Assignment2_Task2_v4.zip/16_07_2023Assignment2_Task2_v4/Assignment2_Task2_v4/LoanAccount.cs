﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Task2_v4
{
    class LoanAccount:BankAccount,ITransaction
    {
        public int SelectTransactionType;
        public decimal amountToDeposit;
        public decimal amountToWithdraw;
        public decimal interest;
        public bool transactionDeposit;
        public bool transactionWidthdraw;
        public LoanAccount(string AccountNumber, string AccountHolderName, decimal Balance) : base(AccountNumber, AccountHolderName, Balance)
        {
        }
        public override void Deposit(decimal AmountToPayLoan)//Overloading of function Deposit
        {
            amountToDeposit = AmountToPayLoan;
            transactionDeposit = true;
            balance += amountToDeposit;
            addTransaction(amountToDeposit, "Payment Deposited");
            PrintTransaction();

        }
        public override void Withdraw(decimal AmountToWithdraw)//Overloading of function Deposit
        {
            amountToWithdraw = AmountToWithdraw;
            transactionWidthdraw = true;
            if (amountToWithdraw <= balance)
            {
                balance -= amountToWithdraw;
                addTransaction(amountToWithdraw, "Widthdraw");
                PrintTransaction();
            }
            else
            {
                Console.WriteLine("Entered amount is greater than your loan limt. Enter the valid amount...");
            }

        }
        public override void CalculateInterest()
        {
            interest = (decimal)0.30 * balance;
            balance += interest;
            addTransaction(interest, "Interest");
            Console.WriteLine($"The 30% interest is added in your account.\nYour new balance is {balance}");

        }
        public void ExecuteTransaction(decimal amount)
        {
            Console.WriteLine("Press 1 to Pay Loan and 2 to withdraw from account");
            SelectTransactionType = int.Parse(Console.ReadLine());
            switch (SelectTransactionType)
            {
                case 1:
                    Deposit(amountToDeposit);
                    break;
                case 2:
                    Withdraw(amountToWithdraw);
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;

            }

        }
        public void PrintTransaction()
        {
            if (transactionWidthdraw)
            {
                Console.WriteLine($"Amount {amountToWithdraw} has been withdrawn from account titled as {accountHolderName}\nYour remaining balance is {balance}");

            }
            else if (transactionDeposit)
            {
                Console.WriteLine($"Amount {amountToDeposit} has been deposited in account titled as {accountHolderName}\nYour new balance is {balance}");
            }
            else
            {
                Console.WriteLine($"Transaction is not available");
            }
        }


    }
}

