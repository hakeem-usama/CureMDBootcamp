﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Task2_v4
{
    public abstract class BankAccount
    {
        private string account_number { set; get; }
        public string accountNumber   // property
        {
            get { return account_number; }   // get method
            set { account_number = value; }  // set method
        }
        private string account_holder_name { set; get; }
        public string accountHolderName   // property
        {
            get { return account_holder_name; }   // get method
            set { account_holder_name = value; }  // set method
        }
        private double balan { set; get; }
        public double balance   // property
        {
            get { return balan; }   // get method
            set { balan = value; }  // set method
        }
        public BankAccount(string AccountNumber, string AccountHolderName, double Balance)
            {
            accountNumber = AccountNumber;
            accountHolderName = AccountHolderName;
            balance = Balance;
            }
        public void Deposit(double amountToDeposit)
        {
            balance += amountToDeposit;
            Console.WriteLine($"Amount {amountToDeposit} has been depsited in account titled as {account_holder_name}\nour new balance is {balance}");

        }
        public void Withdraw(double amountToWithdraw)
        {
            if (amountToWithdraw <= balan)//private variable balan is used so that user cannot update this
            {
                balance -= amountToWithdraw;
                Console.WriteLine($"Amount {amountToWithdraw} has been widthdrawn from account titled as {account_holder_name}\nYour remaining balance is {balance}");
            }
            else
            {
                Console.WriteLine("Low Balance. Enter the valid amount...");
            }
        }
        public abstract void CalculateInterest();// Override this method in each class to calculate the interet by different methods.
        

    }
}
